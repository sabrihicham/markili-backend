<?php

return [
'App_Name' => 'JKJ Dating'
]

?>


<?php $__env->startSection('header'); ?>
    <script src="<?php echo e(asset('asset/script/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }

        *,
        ::after,
        ::before {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
        }

        .mainbg {
            background-color: #0080cb !important;
        }

        .card-icon2 {
            width: 50px;
            height: 50px;
            line-height: 50px;
            font-size: 22px;
            margin: 5px 0px;
            box-shadow: 2px 2px 10px 0 #97979794;
            border-radius: 10px;
            background: #6777ef;
            text-align: center;
        }


        .maincolor {
            color: white !important;
        }

        .text-grey {
            color: #747474 !important;
        }

        .records-tab-div p {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: whitesmoke;
            margin-top: 7px !important;
            margin-bottom: 0 !important;
            padding: 0 10px;
            border-radius: 5px;
        }
    </style>



    <section class="section">
        <div class="ml-4 my-3">

            <h5 class="d-inline"><?php echo e(__('Appointments')); ?></h5>
            <a href="<?php echo e(route('appointments')); ?>"><span class="badge bg-primary text-white"><?php echo e(__('Check')); ?></span></a>
        </div>

        <div class="row col-12">
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div>
                                        <h4 class="font-18 mt-1 text-theme-color"><?php echo e(__('Today')); ?></h4>
                                        <div class="records-tab-div">
                                            <p class="text-grey">
                                                <?php echo e(__('Total : ')); ?><strong><?php echo e($todayTotalBookings); ?>

                                                </strong></p>
                                            <p class="text-grey">
                                                <?php echo e(__('Pending : ')); ?><strong><?php echo e($todayTotalPendingBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Accepted : ')); ?><strong><?php echo e($todayTotalAcceptedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Completed : ')); ?><strong><?php echo e($todayTotalCompletedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Cancelled : ')); ?><strong><?php echo e($todayTotalCancelledBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Declined : ')); ?><strong><?php echo e($todayTotalDeclinedBookings); ?></strong>
                                            </p>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div>
                                        <h4 class="font-18 mt-1 text-theme-color"><?php echo e(__('Last 7 Days')); ?></h4>
                                        <div class="records-tab-div">
                                            <p class="text-grey">
                                                <?php echo e(__('Total : ')); ?><strong><?php echo e($last7daysTotalBookings); ?></strong></p>
                                            <p class="text-grey">
                                                <?php echo e(__('Pending : ')); ?><strong><?php echo e($last7daysTotalPendingBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Accepted : ')); ?><strong><?php echo e($last7daysTotalAcceptedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Completed : ')); ?><strong><?php echo e($last7daysTotalCompletedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Cancelled : ')); ?><strong><?php echo e($last7daysTotalCancelledBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Declined : ')); ?><strong><?php echo e($last7daysTotalDeclinedBookings); ?></strong>
                                            </p>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div>
                                        <h4 class="font-18 mt-1 text-theme-color"><?php echo e(__('Last 30 Days')); ?></h4>
                                        <div class="records-tab-div">
                                            <p class="text-grey">
                                                <?php echo e(__('Total : ')); ?><strong><?php echo e($last30daysTotalBookings); ?></strong></p>
                                            <p class="text-grey">
                                                <?php echo e(__('Pending : ')); ?><strong><?php echo e($last30daysTotalPendingBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Accepted : ')); ?><strong><?php echo e($last30daysTotalAcceptedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Completed : ')); ?><strong><?php echo e($last30daysTotalCompletedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Cancelled : ')); ?><strong><?php echo e($last30daysTotalCancelledBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Declined : ')); ?><strong><?php echo e($last30daysTotalDeclinedBookings); ?></strong>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div>
                                        <h4 class="font-18 mt-1 text-theme-color"><?php echo e(__('Last 90 Days')); ?></h4>
                                        <div class="records-tab-div">
                                            <p class="text-grey">
                                                <?php echo e(__('Total : ')); ?><strong><?php echo e($last90daysTotalBookings); ?></strong></p>
                                            <p class="text-grey">
                                                <?php echo e(__('Pending : ')); ?><strong><?php echo e($last90daysTotalPendingBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Accepted : ')); ?><strong><?php echo e($last90daysTotalAcceptedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Completed : ')); ?><strong><?php echo e($last90daysTotalCompletedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Cancelled : ')); ?><strong><?php echo e($last90daysTotalCancelledBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Declined : ')); ?><strong><?php echo e($last90daysTotalDeclinedBookings); ?></strong>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div>
                                        <h4 class="font-18 mt-1 text-theme-color"><?php echo e(__('Last 180 Days')); ?></h4>
                                        <div class="records-tab-div">
                                            <p class="text-grey">
                                                <?php echo e(__('Total : ')); ?><strong><?php echo e($last180daysTotalBookings); ?></strong></p>
                                            <p class="text-grey">
                                                <?php echo e(__('Pending : ')); ?><strong><?php echo e($last180daysTotalPendingBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Accepted : ')); ?><strong><?php echo e($last180daysTotalAcceptedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Completed : ')); ?><strong><?php echo e($last180daysTotalCompletedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Cancelled : ')); ?><strong><?php echo e($last180daysTotalCancelledBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Declined : ')); ?><strong><?php echo e($last180daysTotalDeclinedBookings); ?></strong>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div>
                                        <h4 class="font-18 mt-1 text-theme-color"><?php echo e(__('All Time')); ?></h4>
                                        <div class="records-tab-div">
                                            <p class="text-grey">
                                                <?php echo e(__('Total : ')); ?><strong><?php echo e($allTimeTotalBookings); ?></strong></p>
                                            <p class="text-grey">
                                                <?php echo e(__('Pending : ')); ?><strong><?php echo e($allTimeTotalPendingBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Accepted : ')); ?><strong><?php echo e($allTimeTotalAcceptedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Completed : ')); ?><strong><?php echo e($allTimeTotalCompletedBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Cancelled : ')); ?><strong><?php echo e($allTimeTotalCancelledBookings); ?></strong>
                                            </p>
                                            <p class="text-grey">
                                                <?php echo e(__('Declined : ')); ?><strong><?php echo e($allTimeTotalDeclinedBookings); ?></strong>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="ml-4 my-3">
            <h5 class="d-inline"><?php echo e(__('Doctors')); ?></h5>
            <a href="<?php echo e(route('doctors')); ?>"><span class="badge bg-primary text-white"><?php echo e(__('Check')); ?></span></a>
        </div>
        <div class="row col-12">
            
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($activeDoctors); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Active')); ?></h5>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($pendingDoctors); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Pending')); ?></h5>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($bannedDoctors); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Banned')); ?></h5>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        
        <div class="ml-4 my-3">
            <h5 class="d-inline"><?php echo e(__('Platform Earnings')); ?></h5>
            <a href="<?php echo e(route('platformEarnings')); ?>"><span
                    class="badge bg-primary text-white"><?php echo e(__('Check')); ?></span></a>
        </div>
        <div class="row col-12">
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($todayEarnings); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Today')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($last7DaysEarnings); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Last 7 Days')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($last30DaysEarnings); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Last 30 Days')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($last90DaysEarnings); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Last 90 Days')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($last180DaysEarnings); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Last 180 Days')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($allTimeDaysEarnings); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('All Time')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="ml-4 my-3">
            <h5 class="d-inline"><?php echo e(__('Withdrawals')); ?></h5>
        </div>
        <div class="row col-12">
            
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($pendingDoctorPayouts); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Pending Payouts (Doctor)')); ?></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($completedDoctorPayouts); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Completed Payouts (Doctor)')); ?></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($pendingUserPayouts); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Pending Payouts (User)')); ?></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="ml-4 my-3">
            <h5 class="d-inline"><?php echo e(__('User Wallet Recharge')); ?></h5>
            <a href="<?php echo e(route('userWalletRecharge')); ?>"><span
                    class="badge bg-primary text-white"><?php echo e(__('Check')); ?></span></a>
        </div>
        <div class="row col-12">
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($todayRecharges); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Today')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($last7DaysRecharges); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Last 7 Days')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($last30DaysRecharges); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Last 30 Days')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($last90DaysRecharges); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Last 90 Days')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($last180DaysRecharges); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('Last 180 Days')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div>
                                        <h4 class="mb-2 "><?php echo e($settings->currency); ?><?php echo e($allTimeRecharges); ?></h4>
                                        <h5 class="font-15 mt-1 text-grey"><?php echo e(__('All Time')); ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('include.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doctorio_backend\resources\views/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('header'); ?>
    <script src="<?php echo e(asset('asset/script/reviews.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .starDisabled {
            color: rgb(184, 184, 184) !important;
        }

        .starActive {
            color: orangered !important;
        }

        .reviewsTable table.dataTable th,
        .reviewsTable table.dataTable td {
            white-space: unset !important;
        }


        .w-30 {
            width: 30% !important;
        }
    </style>
    <div class="card mt-3">
        <div class="card-header">
            <h4><?php echo e(__('Reviews')); ?></h4>
        </div>
        <div class="card-body">
            <div class="table-responsive col-12">
                <table class="table table-striped w-100 word-wrap reviewsTable" id="reviewsTable">
                    <thead>
                        <tr>
                            <th><?php echo e(__('Rating')); ?></th>
                            <th class="w-30"><?php echo e(__('Comment')); ?></th>
                            <th><?php echo e(__('Appointment')); ?></th>
                            <th><?php echo e(__('Doctor')); ?></th>
                            <th><?php echo e(__('Date&Time')); ?></th>
                            <th><?php echo e(__('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('include.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doctorio_backend\resources\views/reviews.blade.php ENDPATH**/ ?>
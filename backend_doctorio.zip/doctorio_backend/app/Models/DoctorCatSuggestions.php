<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DoctorCatSuggestions extends Model
{
    use HasFactory;
    public $table = "doctor_cat_suggestion";
}
